"""Sample test configuration file.

Author: Mason Pride
Version: 0.1
"""
