"""SecondhandAuto Package.

This is the __init__ file for this package.

Typically this file can be left blank, but for this example we have
included a print statement so we can see what it does and when.

Author: Mason Pride mtpride@ksu.edu
Version: 0.1
"""

print("In /src/SecondhandAuto/__init__.py")
