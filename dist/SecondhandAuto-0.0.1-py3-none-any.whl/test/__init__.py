"""Test package for SecondhandAuto.

Author: Mason Pride
Version: 0.1
"""
